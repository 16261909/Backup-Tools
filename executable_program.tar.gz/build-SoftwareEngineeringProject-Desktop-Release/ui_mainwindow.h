/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *BackupTab;
    QWidget *layoutWidget_4;
    QGridLayout *BackupLayout;
    QLineEdit *BackupSourceLine;
    QPushButton *BackupSourceFolderButton;
    QSpacerItem *verticalSpacer_13;
    QSpacerItem *verticalSpacer_14;
    QSpacerItem *verticalSpacer_15;
    QLabel *label_10;
    QLineEdit *BackupDestLine;
    QPushButton *BackupDestFolderButton;
    QLabel *label_9;
    QPushButton *BackupButton;
    QCheckBox *BackupKeepCB;
    QCheckBox *BackupPackCB;
    QCheckBox *BackupCompressCB;
    QCheckBox *BackupEncryptCB;
    QWidget *layoutWidget;
    QHBoxLayout *BackupPasswordLO;
    QLabel *label_11;
    QLineEdit *BackupPasswordLine;
    QLabel *label;
    QPushButton *ResetButton;
    QLabel *FilterLabel;
    QPushButton *FilterButton;
    QCheckBox *BackupClearCB;
    QWidget *PackTab;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_5;
    QLabel *label_5;
    QLineEdit *PackSourceLine;
    QPushButton *PackSourceFolderButton;
    QSpacerItem *verticalSpacer_7;
    QSpacerItem *verticalSpacer_8;
    QSpacerItem *verticalSpacer_9;
    QLabel *label_6;
    QLineEdit *PackDestLine;
    QPushButton *PackDestFolderButton;
    QPushButton *PackButton;
    QWidget *UnpackTab;
    QPushButton *UnpackButton;
    QWidget *layoutWidget_8;
    QGridLayout *gridLayout_9;
    QLabel *label_17;
    QLineEdit *UnpackSourceLine;
    QPushButton *UnpackSourceFolderButton;
    QSpacerItem *verticalSpacer_25;
    QSpacerItem *verticalSpacer_26;
    QSpacerItem *verticalSpacer_27;
    QLabel *label_18;
    QLineEdit *UnpackDestLine;
    QPushButton *UnpackDestFolderButton;
    QCheckBox *UnpackClearCB;
    QWidget *CompressTab;
    QWidget *layoutWidget_3;
    QGridLayout *gridLayout_6;
    QLabel *label_7;
    QLineEdit *CompressSourceLine;
    QPushButton *CompressSourceFolderButton;
    QSpacerItem *verticalSpacer_10;
    QSpacerItem *verticalSpacer_11;
    QSpacerItem *verticalSpacer_12;
    QLabel *label_8;
    QLineEdit *CompressDestLine;
    QPushButton *CompressDestFolderButton;
    QPushButton *CompressButton;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *CompressEncryptCB;
    QLineEdit *CompressPasswordLine;
    QLabel *label_2;
    QCheckBox *CompressKeepCB;
    QWidget *DecompressTab;
    QPushButton *DecompressButton;
    QWidget *layoutWidget_9;
    QGridLayout *gridLayout_10;
    QLabel *label_19;
    QLineEdit *DecompressSourceLine;
    QPushButton *DecompressSourceFolderButton;
    QSpacerItem *verticalSpacer_28;
    QSpacerItem *verticalSpacer_29;
    QSpacerItem *verticalSpacer_30;
    QLabel *label_20;
    QLineEdit *DecompressDestLine;
    QPushButton *DecompressDestFolderButton;
    QLabel *label_3;
    QLineEdit *DecompressPasswordLine;
    QLabel *label_4;
    QCheckBox *DecompressKeepCB;
    QCheckBox *DecompressUnpackCB;
    QCheckBox *DecompressClearCB;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        MainWindow->setMinimumSize(QSize(800, 600));
        MainWindow->setMaximumSize(QSize(800, 600));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 800, 600));
        tabWidget->setMinimumSize(QSize(800, 600));
        tabWidget->setMaximumSize(QSize(800, 600));
        tabWidget->setContextMenuPolicy(Qt::NoContextMenu);
        BackupTab = new QWidget();
        BackupTab->setObjectName(QString::fromUtf8("BackupTab"));
        layoutWidget_4 = new QWidget(BackupTab);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(90, 90, 621, 108));
        BackupLayout = new QGridLayout(layoutWidget_4);
        BackupLayout->setObjectName(QString::fromUtf8("BackupLayout"));
        BackupLayout->setContentsMargins(0, 0, 0, 0);
        BackupSourceLine = new QLineEdit(layoutWidget_4);
        BackupSourceLine->setObjectName(QString::fromUtf8("BackupSourceLine"));

        BackupLayout->addWidget(BackupSourceLine, 0, 1, 1, 1);

        BackupSourceFolderButton = new QPushButton(layoutWidget_4);
        BackupSourceFolderButton->setObjectName(QString::fromUtf8("BackupSourceFolderButton"));

        BackupLayout->addWidget(BackupSourceFolderButton, 0, 2, 1, 1);

        verticalSpacer_13 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        BackupLayout->addItem(verticalSpacer_13, 1, 0, 1, 1);

        verticalSpacer_14 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        BackupLayout->addItem(verticalSpacer_14, 1, 1, 1, 1);

        verticalSpacer_15 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        BackupLayout->addItem(verticalSpacer_15, 1, 2, 1, 1);

        label_10 = new QLabel(layoutWidget_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        BackupLayout->addWidget(label_10, 2, 0, 1, 1);

        BackupDestLine = new QLineEdit(layoutWidget_4);
        BackupDestLine->setObjectName(QString::fromUtf8("BackupDestLine"));

        BackupLayout->addWidget(BackupDestLine, 2, 1, 1, 1);

        BackupDestFolderButton = new QPushButton(layoutWidget_4);
        BackupDestFolderButton->setObjectName(QString::fromUtf8("BackupDestFolderButton"));

        BackupLayout->addWidget(BackupDestFolderButton, 2, 2, 1, 1);

        label_9 = new QLabel(layoutWidget_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        BackupLayout->addWidget(label_9, 0, 0, 1, 1);

        BackupButton = new QPushButton(BackupTab);
        BackupButton->setObjectName(QString::fromUtf8("BackupButton"));
        BackupButton->setGeometry(QRect(600, 430, 100, 27));
        BackupKeepCB = new QCheckBox(BackupTab);
        BackupKeepCB->setObjectName(QString::fromUtf8("BackupKeepCB"));
        BackupKeepCB->setGeometry(QRect(390, 430, 211, 25));
        BackupPackCB = new QCheckBox(BackupTab);
        BackupPackCB->setObjectName(QString::fromUtf8("BackupPackCB"));
        BackupPackCB->setGeometry(QRect(90, 220, 105, 25));
        BackupCompressCB = new QCheckBox(BackupTab);
        BackupCompressCB->setObjectName(QString::fromUtf8("BackupCompressCB"));
        BackupCompressCB->setGeometry(QRect(210, 220, 111, 25));
        BackupEncryptCB = new QCheckBox(BackupTab);
        BackupEncryptCB->setObjectName(QString::fromUtf8("BackupEncryptCB"));
        BackupEncryptCB->setGeometry(QRect(350, 220, 111, 25));
        layoutWidget = new QWidget(BackupTab);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 260, 641, 29));
        BackupPasswordLO = new QHBoxLayout(layoutWidget);
        BackupPasswordLO->setObjectName(QString::fromUtf8("BackupPasswordLO"));
        BackupPasswordLO->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        BackupPasswordLO->addWidget(label_11);

        BackupPasswordLine = new QLineEdit(layoutWidget);
        BackupPasswordLine->setObjectName(QString::fromUtf8("BackupPasswordLine"));

        BackupPasswordLO->addWidget(BackupPasswordLine);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        BackupPasswordLO->addWidget(label);

        ResetButton = new QPushButton(BackupTab);
        ResetButton->setObjectName(QString::fromUtf8("ResetButton"));
        ResetButton->setGeometry(QRect(600, 370, 100, 27));
        FilterLabel = new QLabel(BackupTab);
        FilterLabel->setObjectName(QString::fromUtf8("FilterLabel"));
        FilterLabel->setGeometry(QRect(390, 374, 79, 19));
        FilterButton = new QPushButton(BackupTab);
        FilterButton->setObjectName(QString::fromUtf8("FilterButton"));
        FilterButton->setGeometry(QRect(470, 370, 100, 27));
        BackupClearCB = new QCheckBox(BackupTab);
        BackupClearCB->setObjectName(QString::fromUtf8("BackupClearCB"));
        BackupClearCB->setGeometry(QRect(170, 430, 211, 25));
        tabWidget->addTab(BackupTab, QString());
        PackTab = new QWidget();
        PackTab->setObjectName(QString::fromUtf8("PackTab"));
        layoutWidget_2 = new QWidget(PackTab);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(90, 90, 621, 108));
        gridLayout_5 = new QGridLayout(layoutWidget_2);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_5->addWidget(label_5, 0, 0, 1, 1);

        PackSourceLine = new QLineEdit(layoutWidget_2);
        PackSourceLine->setObjectName(QString::fromUtf8("PackSourceLine"));

        gridLayout_5->addWidget(PackSourceLine, 0, 1, 1, 1);

        PackSourceFolderButton = new QPushButton(layoutWidget_2);
        PackSourceFolderButton->setObjectName(QString::fromUtf8("PackSourceFolderButton"));

        gridLayout_5->addWidget(PackSourceFolderButton, 0, 2, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_7, 1, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_8, 1, 1, 1, 1);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_9, 1, 2, 1, 1);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_5->addWidget(label_6, 2, 0, 1, 1);

        PackDestLine = new QLineEdit(layoutWidget_2);
        PackDestLine->setObjectName(QString::fromUtf8("PackDestLine"));

        gridLayout_5->addWidget(PackDestLine, 2, 1, 1, 1);

        PackDestFolderButton = new QPushButton(layoutWidget_2);
        PackDestFolderButton->setObjectName(QString::fromUtf8("PackDestFolderButton"));

        gridLayout_5->addWidget(PackDestFolderButton, 2, 2, 1, 1);

        PackButton = new QPushButton(PackTab);
        PackButton->setObjectName(QString::fromUtf8("PackButton"));
        PackButton->setGeometry(QRect(600, 410, 100, 27));
        tabWidget->addTab(PackTab, QString());
        UnpackTab = new QWidget();
        UnpackTab->setObjectName(QString::fromUtf8("UnpackTab"));
        UnpackButton = new QPushButton(UnpackTab);
        UnpackButton->setObjectName(QString::fromUtf8("UnpackButton"));
        UnpackButton->setGeometry(QRect(600, 420, 100, 27));
        layoutWidget_8 = new QWidget(UnpackTab);
        layoutWidget_8->setObjectName(QString::fromUtf8("layoutWidget_8"));
        layoutWidget_8->setGeometry(QRect(90, 90, 621, 108));
        gridLayout_9 = new QGridLayout(layoutWidget_8);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        label_17 = new QLabel(layoutWidget_8);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_9->addWidget(label_17, 0, 0, 1, 1);

        UnpackSourceLine = new QLineEdit(layoutWidget_8);
        UnpackSourceLine->setObjectName(QString::fromUtf8("UnpackSourceLine"));

        gridLayout_9->addWidget(UnpackSourceLine, 0, 1, 1, 1);

        UnpackSourceFolderButton = new QPushButton(layoutWidget_8);
        UnpackSourceFolderButton->setObjectName(QString::fromUtf8("UnpackSourceFolderButton"));

        gridLayout_9->addWidget(UnpackSourceFolderButton, 0, 2, 1, 1);

        verticalSpacer_25 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_9->addItem(verticalSpacer_25, 1, 0, 1, 1);

        verticalSpacer_26 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_9->addItem(verticalSpacer_26, 1, 1, 1, 1);

        verticalSpacer_27 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_9->addItem(verticalSpacer_27, 1, 2, 1, 1);

        label_18 = new QLabel(layoutWidget_8);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_9->addWidget(label_18, 2, 0, 1, 1);

        UnpackDestLine = new QLineEdit(layoutWidget_8);
        UnpackDestLine->setObjectName(QString::fromUtf8("UnpackDestLine"));

        gridLayout_9->addWidget(UnpackDestLine, 2, 1, 1, 1);

        UnpackDestFolderButton = new QPushButton(layoutWidget_8);
        UnpackDestFolderButton->setObjectName(QString::fromUtf8("UnpackDestFolderButton"));

        gridLayout_9->addWidget(UnpackDestFolderButton, 2, 2, 1, 1);

        UnpackClearCB = new QCheckBox(UnpackTab);
        UnpackClearCB->setObjectName(QString::fromUtf8("UnpackClearCB"));
        UnpackClearCB->setGeometry(QRect(380, 420, 211, 25));
        tabWidget->addTab(UnpackTab, QString());
        CompressTab = new QWidget();
        CompressTab->setObjectName(QString::fromUtf8("CompressTab"));
        layoutWidget_3 = new QWidget(CompressTab);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(90, 90, 621, 108));
        gridLayout_6 = new QGridLayout(layoutWidget_3);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_6->addWidget(label_7, 0, 0, 1, 1);

        CompressSourceLine = new QLineEdit(layoutWidget_3);
        CompressSourceLine->setObjectName(QString::fromUtf8("CompressSourceLine"));

        gridLayout_6->addWidget(CompressSourceLine, 0, 1, 1, 1);

        CompressSourceFolderButton = new QPushButton(layoutWidget_3);
        CompressSourceFolderButton->setObjectName(QString::fromUtf8("CompressSourceFolderButton"));

        gridLayout_6->addWidget(CompressSourceFolderButton, 0, 2, 1, 1);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_6->addItem(verticalSpacer_10, 1, 0, 1, 1);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_6->addItem(verticalSpacer_11, 1, 1, 1, 1);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_6->addItem(verticalSpacer_12, 1, 2, 1, 1);

        label_8 = new QLabel(layoutWidget_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_6->addWidget(label_8, 2, 0, 1, 1);

        CompressDestLine = new QLineEdit(layoutWidget_3);
        CompressDestLine->setObjectName(QString::fromUtf8("CompressDestLine"));

        gridLayout_6->addWidget(CompressDestLine, 2, 1, 1, 1);

        CompressDestFolderButton = new QPushButton(layoutWidget_3);
        CompressDestFolderButton->setObjectName(QString::fromUtf8("CompressDestFolderButton"));

        gridLayout_6->addWidget(CompressDestFolderButton, 2, 2, 1, 1);

        CompressButton = new QPushButton(CompressTab);
        CompressButton->setObjectName(QString::fromUtf8("CompressButton"));
        CompressButton->setGeometry(QRect(600, 430, 111, 27));
        layoutWidget1 = new QWidget(CompressTab);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(80, 250, 631, 29));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        CompressEncryptCB = new QCheckBox(layoutWidget1);
        CompressEncryptCB->setObjectName(QString::fromUtf8("CompressEncryptCB"));

        horizontalLayout_2->addWidget(CompressEncryptCB);

        CompressPasswordLine = new QLineEdit(layoutWidget1);
        CompressPasswordLine->setObjectName(QString::fromUtf8("CompressPasswordLine"));

        horizontalLayout_2->addWidget(CompressPasswordLine);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        CompressKeepCB = new QCheckBox(CompressTab);
        CompressKeepCB->setObjectName(QString::fromUtf8("CompressKeepCB"));
        CompressKeepCB->setGeometry(QRect(390, 430, 211, 25));
        tabWidget->addTab(CompressTab, QString());
        DecompressTab = new QWidget();
        DecompressTab->setObjectName(QString::fromUtf8("DecompressTab"));
        DecompressButton = new QPushButton(DecompressTab);
        DecompressButton->setObjectName(QString::fromUtf8("DecompressButton"));
        DecompressButton->setGeometry(QRect(590, 430, 111, 27));
        layoutWidget_9 = new QWidget(DecompressTab);
        layoutWidget_9->setObjectName(QString::fromUtf8("layoutWidget_9"));
        layoutWidget_9->setGeometry(QRect(90, 90, 621, 108));
        gridLayout_10 = new QGridLayout(layoutWidget_9);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        gridLayout_10->setContentsMargins(0, 0, 0, 0);
        label_19 = new QLabel(layoutWidget_9);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_10->addWidget(label_19, 0, 0, 1, 1);

        DecompressSourceLine = new QLineEdit(layoutWidget_9);
        DecompressSourceLine->setObjectName(QString::fromUtf8("DecompressSourceLine"));

        gridLayout_10->addWidget(DecompressSourceLine, 0, 1, 1, 1);

        DecompressSourceFolderButton = new QPushButton(layoutWidget_9);
        DecompressSourceFolderButton->setObjectName(QString::fromUtf8("DecompressSourceFolderButton"));

        gridLayout_10->addWidget(DecompressSourceFolderButton, 0, 2, 1, 1);

        verticalSpacer_28 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_28, 1, 0, 1, 1);

        verticalSpacer_29 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_29, 1, 1, 1, 1);

        verticalSpacer_30 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_30, 1, 2, 1, 1);

        label_20 = new QLabel(layoutWidget_9);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_10->addWidget(label_20, 2, 0, 1, 1);

        DecompressDestLine = new QLineEdit(layoutWidget_9);
        DecompressDestLine->setObjectName(QString::fromUtf8("DecompressDestLine"));

        gridLayout_10->addWidget(DecompressDestLine, 2, 1, 1, 1);

        DecompressDestFolderButton = new QPushButton(layoutWidget_9);
        DecompressDestFolderButton->setObjectName(QString::fromUtf8("DecompressDestFolderButton"));

        gridLayout_10->addWidget(DecompressDestFolderButton, 2, 2, 1, 1);

        label_3 = new QLabel(DecompressTab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(90, 260, 191, 20));
        DecompressPasswordLine = new QLineEdit(DecompressTab);
        DecompressPasswordLine->setObjectName(QString::fromUtf8("DecompressPasswordLine"));
        DecompressPasswordLine->setGeometry(QRect(190, 290, 381, 27));
        label_4 = new QLabel(DecompressTab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(580, 290, 136, 27));
        DecompressKeepCB = new QCheckBox(DecompressTab);
        DecompressKeepCB->setObjectName(QString::fromUtf8("DecompressKeepCB"));
        DecompressKeepCB->setGeometry(QRect(380, 430, 211, 25));
        DecompressUnpackCB = new QCheckBox(DecompressTab);
        DecompressUnpackCB->setObjectName(QString::fromUtf8("DecompressUnpackCB"));
        DecompressUnpackCB->setGeometry(QRect(90, 350, 105, 25));
        DecompressClearCB = new QCheckBox(DecompressTab);
        DecompressClearCB->setObjectName(QString::fromUtf8("DecompressClearCB"));
        DecompressClearCB->setGeometry(QRect(160, 430, 211, 25));
        tabWidget->addTab(DecompressTab, QString());
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Backup Tools", nullptr));
        BackupSourceFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "Destination", nullptr));
        BackupDestFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "Source", nullptr));
        BackupButton->setText(QApplication::translate("MainWindow", "Run", nullptr));
        BackupKeepCB->setText(QApplication::translate("MainWindow", "Keep temporary files?", nullptr));
        BackupPackCB->setText(QApplication::translate("MainWindow", "Pack?", nullptr));
        BackupCompressCB->setText(QApplication::translate("MainWindow", "Compress?", nullptr));
        BackupEncryptCB->setText(QApplication::translate("MainWindow", "Encrypt?", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "Password   ", nullptr));
        label->setText(QApplication::translate("MainWindow", "(Max length = 32)", nullptr));
        ResetButton->setText(QApplication::translate("MainWindow", "Reset", nullptr));
        FilterLabel->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        FilterButton->setText(QApplication::translate("MainWindow", "Filter", nullptr));
        BackupClearCB->setText(QApplication::translate("MainWindow", "Remove empty folders?", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(BackupTab), QApplication::translate("MainWindow", "Backup", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Source", nullptr));
        PackSourceFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "Destination", nullptr));
        PackDestFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        PackButton->setText(QApplication::translate("MainWindow", "Pack", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(PackTab), QApplication::translate("MainWindow", "Pack", nullptr));
        UnpackButton->setText(QApplication::translate("MainWindow", "Unpack", nullptr));
        label_17->setText(QApplication::translate("MainWindow", "Source", nullptr));
        UnpackSourceFolderButton->setText(QApplication::translate("MainWindow", "Select a tar file", nullptr));
        label_18->setText(QApplication::translate("MainWindow", "Destination", nullptr));
        UnpackDestFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        UnpackClearCB->setText(QApplication::translate("MainWindow", "Remove empty folders?", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(UnpackTab), QApplication::translate("MainWindow", "Unpack", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Source", nullptr));
        CompressSourceFolderButton->setText(QApplication::translate("MainWindow", "Select a tar file", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "Destination", nullptr));
        CompressDestFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        CompressButton->setText(QApplication::translate("MainWindow", "Compress", nullptr));
        CompressEncryptCB->setText(QApplication::translate("MainWindow", "Encrypt?", nullptr));
        CompressPasswordLine->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "(Max length=32)", nullptr));
        CompressKeepCB->setText(QApplication::translate("MainWindow", "Keep temporary files?", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(CompressTab), QApplication::translate("MainWindow", "Compress", nullptr));
        DecompressButton->setText(QApplication::translate("MainWindow", "Decompress", nullptr));
        label_19->setText(QApplication::translate("MainWindow", "Source", nullptr));
        DecompressSourceFolderButton->setText(QApplication::translate("MainWindow", "Select a huf file", nullptr));
        label_20->setText(QApplication::translate("MainWindow", "Destination", nullptr));
        DecompressDestFolderButton->setText(QApplication::translate("MainWindow", "Select a folder", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Password(if applicable)", nullptr));
        DecompressPasswordLine->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "(Max length=32)", nullptr));
        DecompressKeepCB->setText(QApplication::translate("MainWindow", "Keep temporary files?", nullptr));
        DecompressUnpackCB->setText(QApplication::translate("MainWindow", "Unpack?", nullptr));
        DecompressClearCB->setText(QApplication::translate("MainWindow", "Remove empty folders?", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(DecompressTab), QApplication::translate("MainWindow", "Decompress", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
