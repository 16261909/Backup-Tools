/********************************************************************************
** Form generated from reading UI file 'filterwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERWIDGET_H
#define UI_FILTERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Filterwidget
{
public:
    QTextEdit *TextEdit;
    QLabel *TipsLabel;
    QWidget *layoutWidget;
    QHBoxLayout *RBG1;
    QRadioButton *PathRB;
    QRadioButton *NameRB;
    QRadioButton *TypeRB;
    QRadioButton *TimeRB;
    QWidget *layoutWidget1;
    QHBoxLayout *RBG2;
    QRadioButton *BlackRB;
    QRadioButton *WhiteRB;
    QPushButton *ConfirmButton;
    QWidget *layoutWidget2;
    QGridLayout *TimeLO;
    QLabel *FromLabel;
    QDateTimeEdit *FromTime;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *verticalSpacer;
    QLabel *Tolabel;
    QDateTimeEdit *ToTime;

    void setupUi(QWidget *Filterwidget)
    {
        if (Filterwidget->objectName().isEmpty())
            Filterwidget->setObjectName(QString::fromUtf8("Filterwidget"));
        Filterwidget->resize(650, 500);
        Filterwidget->setMinimumSize(QSize(650, 500));
        Filterwidget->setMaximumSize(QSize(650, 500));
        TextEdit = new QTextEdit(Filterwidget);
        TextEdit->setObjectName(QString::fromUtf8("TextEdit"));
        TextEdit->setGeometry(QRect(40, 110, 571, 291));
        TipsLabel = new QLabel(Filterwidget);
        TipsLabel->setObjectName(QString::fromUtf8("TipsLabel"));
        TipsLabel->setGeometry(QRect(40, 76, 191, 19));
        layoutWidget = new QWidget(Filterwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 30, 581, 27));
        RBG1 = new QHBoxLayout(layoutWidget);
        RBG1->setObjectName(QString::fromUtf8("RBG1"));
        RBG1->setContentsMargins(0, 0, 0, 0);
        PathRB = new QRadioButton(layoutWidget);
        PathRB->setObjectName(QString::fromUtf8("PathRB"));

        RBG1->addWidget(PathRB);

        NameRB = new QRadioButton(layoutWidget);
        NameRB->setObjectName(QString::fromUtf8("NameRB"));

        RBG1->addWidget(NameRB);

        TypeRB = new QRadioButton(layoutWidget);
        TypeRB->setObjectName(QString::fromUtf8("TypeRB"));

        RBG1->addWidget(TypeRB);

        TimeRB = new QRadioButton(layoutWidget);
        TimeRB->setObjectName(QString::fromUtf8("TimeRB"));

        RBG1->addWidget(TimeRB);

        layoutWidget1 = new QWidget(Filterwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(240, 430, 371, 29));
        RBG2 = new QHBoxLayout(layoutWidget1);
        RBG2->setObjectName(QString::fromUtf8("RBG2"));
        RBG2->setContentsMargins(0, 0, 0, 0);
        BlackRB = new QRadioButton(layoutWidget1);
        BlackRB->setObjectName(QString::fromUtf8("BlackRB"));

        RBG2->addWidget(BlackRB);

        WhiteRB = new QRadioButton(layoutWidget1);
        WhiteRB->setObjectName(QString::fromUtf8("WhiteRB"));

        RBG2->addWidget(WhiteRB);

        ConfirmButton = new QPushButton(layoutWidget1);
        ConfirmButton->setObjectName(QString::fromUtf8("ConfirmButton"));

        RBG2->addWidget(ConfirmButton);

        layoutWidget2 = new QWidget(Filterwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(170, 170, 295, 110));
        TimeLO = new QGridLayout(layoutWidget2);
        TimeLO->setObjectName(QString::fromUtf8("TimeLO"));
        TimeLO->setContentsMargins(0, 0, 0, 0);
        FromLabel = new QLabel(layoutWidget2);
        FromLabel->setObjectName(QString::fromUtf8("FromLabel"));

        TimeLO->addWidget(FromLabel, 0, 0, 1, 1);

        FromTime = new QDateTimeEdit(layoutWidget2);
        FromTime->setObjectName(QString::fromUtf8("FromTime"));
        FromTime->setCurrentSection(QDateTimeEdit::YearSection);
        FromTime->setCalendarPopup(true);
        FromTime->setCurrentSectionIndex(0);

        TimeLO->addWidget(FromTime, 0, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        TimeLO->addItem(verticalSpacer_2, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        TimeLO->addItem(verticalSpacer, 1, 1, 1, 1);

        Tolabel = new QLabel(layoutWidget2);
        Tolabel->setObjectName(QString::fromUtf8("Tolabel"));

        TimeLO->addWidget(Tolabel, 2, 0, 1, 1);

        ToTime = new QDateTimeEdit(layoutWidget2);
        ToTime->setObjectName(QString::fromUtf8("ToTime"));
        ToTime->setCalendarPopup(true);

        TimeLO->addWidget(ToTime, 2, 1, 1, 1);


        retranslateUi(Filterwidget);

        QMetaObject::connectSlotsByName(Filterwidget);
    } // setupUi

    void retranslateUi(QWidget *Filterwidget)
    {
        Filterwidget->setWindowTitle(QApplication::translate("Filterwidget", "Filter", nullptr));
        TipsLabel->setText(QApplication::translate("Filterwidget", "Tips: One for each line", nullptr));
        PathRB->setText(QApplication::translate("Filterwidget", "Path", nullptr));
        NameRB->setText(QApplication::translate("Filterwidget", "Filename", nullptr));
        TypeRB->setText(QApplication::translate("Filterwidget", "Type", nullptr));
        TimeRB->setText(QApplication::translate("Filterwidget", "Time", nullptr));
        BlackRB->setText(QApplication::translate("Filterwidget", "Blacklist", nullptr));
        WhiteRB->setText(QApplication::translate("Filterwidget", "Whitelist", nullptr));
        ConfirmButton->setText(QApplication::translate("Filterwidget", "Confirm", nullptr));
        FromLabel->setText(QApplication::translate("Filterwidget", "from", nullptr));
        Tolabel->setText(QApplication::translate("Filterwidget", "to", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Filterwidget: public Ui_Filterwidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERWIDGET_H
