/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../SoftwareEngineeringProject/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[26];
    char stringdata0[696];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "recv_filter"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 4), // "data"
QT_MOC_LITERAL(4, 29, 23), // "on_FilterButton_clicked"
QT_MOC_LITERAL(5, 53, 22), // "on_ResetButton_clicked"
QT_MOC_LITERAL(6, 76, 35), // "on_BackupSourceFolderButton_c..."
QT_MOC_LITERAL(7, 112, 33), // "on_BackupDestFolderButton_cli..."
QT_MOC_LITERAL(8, 146, 23), // "on_BackupButton_clicked"
QT_MOC_LITERAL(9, 170, 23), // "on_BackupPackCB_clicked"
QT_MOC_LITERAL(10, 194, 27), // "on_BackupCompressCB_clicked"
QT_MOC_LITERAL(11, 222, 26), // "on_BackupEncryptCB_clicked"
QT_MOC_LITERAL(12, 249, 33), // "on_PackSourceFolderButton_cli..."
QT_MOC_LITERAL(13, 283, 31), // "on_PackDestFolderButton_clicked"
QT_MOC_LITERAL(14, 315, 21), // "on_PackButton_clicked"
QT_MOC_LITERAL(15, 337, 35), // "on_UnpackSourceFolderButton_c..."
QT_MOC_LITERAL(16, 373, 33), // "on_UnpackDestFolderButton_cli..."
QT_MOC_LITERAL(17, 407, 23), // "on_UnpackButton_clicked"
QT_MOC_LITERAL(18, 431, 37), // "on_CompressSourceFolderButton..."
QT_MOC_LITERAL(19, 469, 35), // "on_CompressDestFolderButton_c..."
QT_MOC_LITERAL(20, 505, 28), // "on_CompressEncryptCB_clicked"
QT_MOC_LITERAL(21, 534, 25), // "on_CompressButton_clicked"
QT_MOC_LITERAL(22, 560, 39), // "on_DecompressSourceFolderButt..."
QT_MOC_LITERAL(23, 600, 37), // "on_DecompressDestFolderButton..."
QT_MOC_LITERAL(24, 638, 29), // "on_DecompressUnpackCB_clicked"
QT_MOC_LITERAL(25, 668, 27) // "on_DecompressButton_clicked"

    },
    "MainWindow\0recv_filter\0\0data\0"
    "on_FilterButton_clicked\0on_ResetButton_clicked\0"
    "on_BackupSourceFolderButton_clicked\0"
    "on_BackupDestFolderButton_clicked\0"
    "on_BackupButton_clicked\0on_BackupPackCB_clicked\0"
    "on_BackupCompressCB_clicked\0"
    "on_BackupEncryptCB_clicked\0"
    "on_PackSourceFolderButton_clicked\0"
    "on_PackDestFolderButton_clicked\0"
    "on_PackButton_clicked\0"
    "on_UnpackSourceFolderButton_clicked\0"
    "on_UnpackDestFolderButton_clicked\0"
    "on_UnpackButton_clicked\0"
    "on_CompressSourceFolderButton_clicked\0"
    "on_CompressDestFolderButton_clicked\0"
    "on_CompressEncryptCB_clicked\0"
    "on_CompressButton_clicked\0"
    "on_DecompressSourceFolderButton_clicked\0"
    "on_DecompressDestFolderButton_clicked\0"
    "on_DecompressUnpackCB_clicked\0"
    "on_DecompressButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  129,    2, 0x08 /* Private */,
       4,    0,  132,    2, 0x08 /* Private */,
       5,    0,  133,    2, 0x08 /* Private */,
       6,    0,  134,    2, 0x08 /* Private */,
       7,    0,  135,    2, 0x08 /* Private */,
       8,    0,  136,    2, 0x08 /* Private */,
       9,    0,  137,    2, 0x08 /* Private */,
      10,    0,  138,    2, 0x08 /* Private */,
      11,    0,  139,    2, 0x08 /* Private */,
      12,    0,  140,    2, 0x08 /* Private */,
      13,    0,  141,    2, 0x08 /* Private */,
      14,    0,  142,    2, 0x08 /* Private */,
      15,    0,  143,    2, 0x08 /* Private */,
      16,    0,  144,    2, 0x08 /* Private */,
      17,    0,  145,    2, 0x08 /* Private */,
      18,    0,  146,    2, 0x08 /* Private */,
      19,    0,  147,    2, 0x08 /* Private */,
      20,    0,  148,    2, 0x08 /* Private */,
      21,    0,  149,    2, 0x08 /* Private */,
      22,    0,  150,    2, 0x08 /* Private */,
      23,    0,  151,    2, 0x08 /* Private */,
      24,    0,  152,    2, 0x08 /* Private */,
      25,    0,  153,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QVariant,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->recv_filter((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 1: _t->on_FilterButton_clicked(); break;
        case 2: _t->on_ResetButton_clicked(); break;
        case 3: _t->on_BackupSourceFolderButton_clicked(); break;
        case 4: _t->on_BackupDestFolderButton_clicked(); break;
        case 5: _t->on_BackupButton_clicked(); break;
        case 6: _t->on_BackupPackCB_clicked(); break;
        case 7: _t->on_BackupCompressCB_clicked(); break;
        case 8: _t->on_BackupEncryptCB_clicked(); break;
        case 9: _t->on_PackSourceFolderButton_clicked(); break;
        case 10: _t->on_PackDestFolderButton_clicked(); break;
        case 11: _t->on_PackButton_clicked(); break;
        case 12: _t->on_UnpackSourceFolderButton_clicked(); break;
        case 13: _t->on_UnpackDestFolderButton_clicked(); break;
        case 14: _t->on_UnpackButton_clicked(); break;
        case 15: _t->on_CompressSourceFolderButton_clicked(); break;
        case 16: _t->on_CompressDestFolderButton_clicked(); break;
        case 17: _t->on_CompressEncryptCB_clicked(); break;
        case 18: _t->on_CompressButton_clicked(); break;
        case 19: _t->on_DecompressSourceFolderButton_clicked(); break;
        case 20: _t->on_DecompressDestFolderButton_clicked(); break;
        case 21: _t->on_DecompressUnpackCB_clicked(); break;
        case 22: _t->on_DecompressButton_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
